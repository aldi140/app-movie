require('dotenv').config();
const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
  console.log("🔐 JWT_SECRET:", process.env.JWT_SECRET);
  const token = req.headers.authorization?.split(' ')[1];
   console.log("📦 Token diterima dari FE:", token); // 

  if (!token) return res.status(401).json({ message: 'No token provided' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(403).json({ message: 'Token invalid or expired' });
  }
};

module.exports = authMiddleware;
