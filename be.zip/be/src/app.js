const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/auth.routes');
const wishlistRoutes = require('./routes/wishlist.routes');

const app = express();
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/wishlist', wishlistRoutes);

app.get('/', (req, res) => res.send('API Running...'));

module.exports = app;
