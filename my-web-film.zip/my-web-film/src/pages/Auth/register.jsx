import { useState } from "react";
import FormRegister from "../../components/commons/organisms/FormRegister";
import AuthTemplate from "../../components/commons/templates/AuthTemplate";
import { register } from "../../services/authService";
import { useNavigate } from "react-router-dom";


const PageRegister = () => {
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const handleRegister = async (e) => {
            e.preventDefault()
            try{
                const data = await register(e.target.name.value, e.target.email.value, e.target.password.value);
                navigate("/login", {state: {success: data.message}});
            }catch(err){
               setError(err.response?.data?.error || "Register failed");;
            }
        }
        console.log(error);
    return (
        <div className="flex h-screen">
            {/* Kolom kiri: Gambar */}
            <div
                className="hidden xl:block xl:w-1/2 bg-cover bg-center"
                style={{ backgroundImage: "url('/assets/img/bg-theater.jpg')" }}
            ></div>

            {/* Kolom kanan: Form Login */}
            <div className="w-full xl:w-1/2 flex items-center justify-center ">
                <AuthTemplate title="Register">
                    <FormRegister handleAuth={handleRegister} />
                </AuthTemplate>
            </div>
        </div>

    );
};


export default PageRegister