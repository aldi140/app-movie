import { useState } from "react";
import FormLogin from "../../components/commons/organisms/FormLogin";
import AuthTemplate from "../../components/commons/templates/AuthTemplate";
import { login } from "../../services/authService";
import { AiFillInfoCircle } from "react-icons/ai";
import { useLocation, useNavigate } from "react-router-dom";


const PageLogin = () => {
    const [error, setError] = useState(null);
    const location = useLocation();
    const navigate = useNavigate();
    const successMessage = location.state?.success;


    const handleLogin = async (e) => {
        e.preventDefault()
        try{
            const data = await login(e.target.email.value, e.target.password.value);
            if(data.token){
                localStorage.setItem("token", JSON.stringify(data.token));
                localStorage.setItem("user", JSON.stringify(data.user));
                navigate("/"); 
            }
        }catch(err){
            setError(err.response.data.message);
        }
    }
    return (
        <div className="flex h-screen">
            {/* Kolom kiri: Gambar */}
            <div
                className="hidden xl:block xl:w-1/2 bg-cover bg-center"
                style={{ backgroundImage: "url('/assets/img/bg-theater.jpg')" }}
            ></div>

            {/* Kolom kanan: Form Login */}
            <div className="w-full xl:w-1/2 flex items-center justify-center ">
                <AuthTemplate title="Login">
                    {error && 
                        <div className="flex items-center gap-x-2 bg-red-200 border border-red-500 text-red-500 py-2 px-4 rounded-md mb-4">
                            <AiFillInfoCircle /> {error}
                        </div>
                    }
                    {successMessage && 
                        <div className="flex items-center gap-x-2 bg-green-200 border border-green-500 text-green-500 py-2 px-4 rounded-md mb-4">
                            <AiFillInfoCircle /> {successMessage}
                        </div>
                    }
                    <FormLogin handleAuth={handleLogin}/>
                </AuthTemplate>
            </div>
        </div>

    );
};


export default PageLogin