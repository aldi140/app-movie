import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { baseURLImg, getGenreMovie, getMovieByGenre } from "../../api";
import CardMedium from "../../components/commons/atoms/CardMedium";
import CardSkeleton from "../../components/commons/atoms/CardMedium/skeleton";

const PageCategory = () => {
    const [movies, setMovies] = useState([]);
    const [loading, setLoading] = useState(false);
    const [genreId, setGenreId] = useState(null);
    const [skeletonCount, setSkeletonCount] = useState(0);
    const [page, setPage] = useState(1);
    const { category } = useParams();
    const [error, setError] = useState(null);
    const [loadingMore, setLoadingMore] = useState(false);

    // console.log(category);

    useEffect(() => {
        getGenreMovie().then(res => {
            const genre = res.data.genres.find(g => g.name === category);
            if (!genre) {
                setError("Genre tidak ditemukan");
                setMovies([]);
                return;
            }
            setGenreId(genre.id)
            setPage(1)
            //  console.log(genreID);
        }).catch(err => {
            console.log(err);
            setError(err.message);
            setLoading(false);
        })
    }, [category])
    // console.log(genreId);


    useEffect(() => {
        if (!genreId) return
        getMovieByGenre(genreId, page).then(res => {
            setLoading(true);
            const newMovies = res.data.results;
            if (page === 1) {
                setMovies(newMovies)
            } else {
                setMovies((prev) => [...prev, ...res.data.results])
            }
            setSkeletonCount(newMovies.length)
            setLoading(false)
            setLoadingMore(false)

        }).catch(err => {
            console.log(err);
            setError("Gagal mengambil data film");
            setLoading(false);
        })

    }, [genreId, page])

    const hanldeSeeMore = () => {
        if (page < 3) {

            setPage((prev) => prev + 1);

            setLoadingMore(true);
        }
    };

    console.log('movie berdasarkan genre', category, movies);

    return (
        <div>
            <div className="w-full py-28 max-w-6xl mx-auto">
                <div className="flex items-center mb-3">
                    <h1 className="text-base md:text-xl font-bold text-white">{category}</h1>
                </div>

                {error && <p className="text-red-500">{error}</p>}

                <div className="w-full flex gap-3 flex-wrap">
                    {loading && !error && (
                        Array.from({ length: skeletonCount}).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                    )}

                    {!loading && !error &&
                        movies.map((movie, index) => (
                            <CardMedium key={index} movies={movie} baseUrlImg={baseURLImg} />
                        ))
                    }
                </div>

                {!loading && page < 3 && (
                    <div className="w-full flex justify-center mt-10">
                        {loadingMore ? (
                            <p className="text-white">Loading...</p>
                        ) : (
                            <button
                                className="w-full mt-3 mx-auto text-sm text-stone-400"
                                onClick={hanldeSeeMore}
                            >
                                See more
                            </button>
                        )}
                    </div>
                )}
            </div>
        </div>
    );

}

export default PageCategory