import Navigation from "./navigation.layout"

const MainLayout = ({children}) => {
    return (
        <div className="relative">
            <Navigation/>
                {children}
        </div>
    )
}

export default MainLayout