import { useEffect, useState } from "react"
import { getMovie, getMovieAnimation, getMovieAnime} from "../../api"
import CardList from "../commons/moleculs/CardList"

const MovieList = ({ baseUrlImg }) => {
    const [moviesPopular, setMoviePopular] = useState([])
    const [moviesTopRated, setMovieTopRated] = useState([])
    const [moviesUpcoming, setMovieUpcoming] = useState([])
    const [moviesNowPlaying, setMovieNowPlaying] = useState([])
    const [movieAnimation, setMovieAnimation] = useState([])
    const [movieAnime, setMovieAnime] = useState([])


    useEffect(() => {
        getMovie('popular').then(res => {
            const limit = res.data.results.slice(0, 10);
            setMoviePopular(limit)
        }).catch((err) => {
            console.log(err);
        })
    }, [])
    useEffect(() => {
        getMovie('top_rated').then(res => {
            const limit = res.data.results.slice(0, 10);
            setMovieTopRated(limit)
        }).catch((err) => {
            console.log(err);
        })
    }, [])
    useEffect(() => {
        getMovie('upcoming').then(res => {
            setMovieUpcoming(res.data.results)
        }).catch((err) => {
            console.log(err);
        })
    }, [])
    useEffect(() => {
        getMovie('now_playing').then(res => {
            setMovieNowPlaying(res.data.results)
        }).catch((err) => {
            console.log(err);
        })
    }, [])

    useEffect(() => {
        getMovieAnimation().then(res => {
            const limit = res.data.results.slice(0, 20);
            setMovieAnimation(limit)
        }).catch((err) => {
            console.log(err);
        })
    }, [])

    useEffect(() => {
        getMovieAnime().then(res => {
            const limit = res.data.results.slice(0, 20);
            setMovieAnime(limit)
        }).catch((err) => {
            console.log(err);
        })
    }, [])

    console.log(movieAnime);
    return (
        <div className="w-full p-2">
            <div className="w-full bg-gradient-to-tl from-gray-900/20 to-white/20 backdrop-blur-3xl rounded-xl p-4 shadow-2xl">
                <div className="flex justify-between items-center mb-3">
                    <h1 className="text-base md:text-xl font-bold text-white">Most Popular</h1>
                    <p className="text-sm text-stone-400">See all</p>
                </div>
                <CardList movies={moviesPopular} baseUrlImg={baseUrlImg} useBackdrop={false} cardMedium={true} />
            </div>
            
            <div className="p-4 w-full">
                <div className="flex justify-between items-center mb-3">
                    <h1 className="text-base md:text-xl font-bold text-white">Top Rated</h1>
                    <p className="text-sm text-stone-400">See all</p>
                </div>
                <CardList movies={moviesTopRated} baseUrlImg={baseUrlImg} useBackdrop={false} cardLarge={true} />
            </div>

            <div className="p-4 w-full">
                <div className="flex justify-between items-center mb-3">
                    <h1 className="text-base md:text-xl font-bold text-white">Now Playing</h1>
                    <p className="text-sm text-stone-400">See all</p>
                </div>
                <CardList movies={moviesNowPlaying} baseUrlImg={baseUrlImg} useBackdrop={false} cardMedium={true} />
            </div>
            <div className="p-4 w-full">
                <div className="flex justify-between items-center mb-3">
                    <h1 className="text-base md:text-xl font-bold text-white">Now Playing</h1>
                    <p className="text-sm text-stone-400">See all</p>
                </div>
                <CardList movies={moviesUpcoming} baseUrlImg={baseUrlImg} useBackdrop={false} cardMedium={true} />
            </div>

            
            <div className="p-4 w-full">
                <div className="flex justify-between items-center mb-3">
                    <h1 className="text-base md:text-xl font-bold text-white">Animation</h1>
                    <p className="text-sm text-stone-400">See all</p>
                </div>
                <CardList movies={movieAnimation} baseUrlImg={baseUrlImg} useBackdrop={true} cardMedium={true} />
            </div>
            <div className="p-4 w-full">
                <div className="flex justify-between items-center mb-3">
                    <h1 className="text-base md:text-xl font-bold text-white">Anime</h1>
                    <p className="text-sm text-stone-400">See all</p>
                </div>
                <CardList movies={movieAnime} baseUrlImg={baseUrlImg} useBackdrop={true} cardMedium={true} />
            </div>
        </div>
    )
}

export default MovieList