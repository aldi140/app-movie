const AuthTemplate = ({ children, title }) => {
    return (
        <div className="w-full max-w-md p-8">
            <h1 className="text-3xl font-bold text-white mb-2">{title}</h1>
            <p className="text-gray-300 mb-6">Back to where the drama, action, and thrill begins.</p>
            {children}
        </div>
    )
}

export default AuthTemplate