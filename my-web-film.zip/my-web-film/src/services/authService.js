import axios from "axios";


const API_BASE = "http://localhost:3300/api/auth";

export const login = async (email, password) => {
    const response = await axios.post(API_BASE + "/login", {
        email,
        password,
    });
    // if (response.data.token) {
    //     localStorage.setItem("user", JSON.stringify(response.data));
    // }
    return response.data;
};


export const register = async (nama, email, password) => {
    const response = await axios.post(API_BASE + "/register", {
        nama,
        email,
        password,
    });
    return response.data;
};